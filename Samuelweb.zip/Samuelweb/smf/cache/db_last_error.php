<?php
$db_last_error = 0;
?>