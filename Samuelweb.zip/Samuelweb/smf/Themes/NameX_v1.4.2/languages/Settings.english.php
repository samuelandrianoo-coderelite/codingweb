<?php

global $settings;

$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = (!empty($settings['theme_real_name']) ? 'Theme: ' . $settings['theme_real_name'] : 'Theme') . '<br/>Author: <a href="https://smftricks.com">SMF Tricks</a><br/><br/>';