<?php
// Version: 2.1.0; Settings

global $settings;

// argument(s): images_url as saved in settings
$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = 'Elementary SMF 2.1 Theme Made By : <a href="https://custom.simplemachines.org/index.php?action=profile;u=218416">TwitchisMental</a>';

?>