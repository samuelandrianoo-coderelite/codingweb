<?php

/**
 * @package Potato Theme
 * @author Sami "SychO" Mazouz
 * @license MIT
 */

require_once __DIR__ . '/Base.php';
require_once __DIR__ . '/Potato.php';

\SychO\Potato::setUp();

require_once __DIR__ . '/helpers.php';
